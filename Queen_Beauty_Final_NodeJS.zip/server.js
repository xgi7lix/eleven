const express = require('express');
const path = require('path');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet({
    contentSecurityPolicy: false,
}));
app.use(compression());
app.use(cors());
app.use(express.json());

// تقديم الملفات الثابتة
app.use(express.static(path.join(__dirname, 'public')));

// حل بسيط ومتوافق مع جميع نسخ Express لإعادة توجيه المسارات إلى index.html
app.use((req, res, next) => {
    // إذا كان الطلب لملف (يحتوي على نقطة)، اتركه يمر
    if (req.path.includes('.')) {
        return next();
    }
    // غير ذلك، أرسل index.html لدعم SPA
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🚀 Server is running on port ${PORT}`);
});
